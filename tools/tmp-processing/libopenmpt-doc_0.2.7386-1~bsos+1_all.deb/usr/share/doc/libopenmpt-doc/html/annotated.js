var annotated =
[
    [ "openmpt", "namespaceopenmpt.html", "namespaceopenmpt" ],
    [ "openmpt_module_initial_ctl", "structopenmpt__module__initial__ctl.html", "structopenmpt__module__initial__ctl" ],
    [ "openmpt_stream_callbacks", "structopenmpt__stream__callbacks.html", "structopenmpt__stream__callbacks" ]
];