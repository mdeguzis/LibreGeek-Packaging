var classopenmpt_1_1exception =
[
    [ "exception", "classopenmpt_1_1exception.html#a06b2116625845ba2dbab1cc77df417ab", null ],
    [ "~exception", "classopenmpt_1_1exception.html#a0a482d5c8a339eaff079dac44d7853d7", null ],
    [ "what", "classopenmpt_1_1exception.html#aae088ca75804ebcffcd02f3c3a895926", null ]
];