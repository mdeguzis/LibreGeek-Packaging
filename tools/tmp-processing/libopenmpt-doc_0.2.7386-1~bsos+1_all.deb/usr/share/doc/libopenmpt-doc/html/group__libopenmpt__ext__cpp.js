var group__libopenmpt__ext__cpp =
[
    [ "openmpt", "namespaceopenmpt.html", null ],
    [ "ext", "namespaceopenmpt_1_1ext.html", null ],
    [ "module_ext", "classopenmpt_1_1module__ext.html", [
      [ "module_ext", "classopenmpt_1_1module__ext.html#a4994cb67b264d14aa849ec2067c6076b", null ],
      [ "module_ext", "classopenmpt_1_1module__ext.html#a31595d7291f0a1fec0f827f1a4a3296d", null ],
      [ "module_ext", "classopenmpt_1_1module__ext.html#a7914d17a610f62eb3b5e8cddeaacbec8", null ],
      [ "module_ext", "classopenmpt_1_1module__ext.html#ac7eaa75faea847d4a63c37e95f745d7a", null ],
      [ "~module_ext", "classopenmpt_1_1module__ext.html#a24ad229c4c23cd7ec9de328e09cdf3dc", null ],
      [ "get_interface", "classopenmpt_1_1module__ext.html#aa98f2d2bb046ea2bc346b8f4839c65ce", null ]
    ] ],
    [ "pattern_vis", "classopenmpt_1_1ext_1_1pattern__vis.html", [
      [ "effect_type", "group__libopenmpt__ext__cpp.html#ga42fdf7dfd8919fa42a8bbb7754cccde3", [
        [ "effect_unknown", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3af10aa914735334b1de44aeec4870345a", null ],
        [ "effect_general", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3a2723a45bc3a57aefe507bcc7e8729ede", null ],
        [ "effect_global", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3a4431ac360b49a3381f32e3c50c8350e9", null ],
        [ "effect_volume", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3a795774dd8f93ab5714e7961449be5f8c", null ],
        [ "effect_panning", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3a7cb096c0556b747289cc9f0136f09be0", null ],
        [ "effect_pitch", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3a1c789ea5244b97959b9b960094e8614e", null ]
      ] ],
      [ "pattern_vis", "classopenmpt_1_1ext_1_1pattern__vis.html#a6f346c9132d63b48a3217983f8570888", null ],
      [ "~pattern_vis", "classopenmpt_1_1ext_1_1pattern__vis.html#a37a386151dabd93ce2069c56252bf499", null ],
      [ "get_pattern_row_channel_effect_type", "classopenmpt_1_1ext_1_1pattern__vis.html#a1c0048a3f55579336b5adcb1c901b90b", null ],
      [ "get_pattern_row_channel_volume_effect_type", "classopenmpt_1_1ext_1_1pattern__vis.html#afc9f85743bf1a24167acb0fcd899c879", null ]
    ] ],
    [ "interactive", "classopenmpt_1_1ext_1_1interactive.html", [
      [ "interactive", "classopenmpt_1_1ext_1_1interactive.html#a905dbc74186d10a96cbd929235300315", null ],
      [ "~interactive", "classopenmpt_1_1ext_1_1interactive.html#a45a86f87d6288788358caf9207bcb796", null ],
      [ "get_channel_mute_status", "classopenmpt_1_1ext_1_1interactive.html#acf307cb660c1f5f3a0d04a052858a263", null ],
      [ "get_channel_volume", "classopenmpt_1_1ext_1_1interactive.html#aa54bc484eed722422107b5de8913ab8c", null ],
      [ "get_global_volume", "classopenmpt_1_1ext_1_1interactive.html#a8e32b907f665b3fc6b1d7ed668efc71c", null ],
      [ "get_instrument_mute_status", "classopenmpt_1_1ext_1_1interactive.html#a48d7a7cdf48c1b18ecd55b05a01013ef", null ],
      [ "get_pitch_factor", "classopenmpt_1_1ext_1_1interactive.html#a39d20ad6bdc958a09e19cf99cffeb67d", null ],
      [ "get_tempo_factor", "classopenmpt_1_1ext_1_1interactive.html#a18a43abf4d28a5c2a6b6ab4e2c3eeeec", null ],
      [ "play_note", "classopenmpt_1_1ext_1_1interactive.html#a9ac033b5c0f0cce7ff65b3258254bd9a", null ],
      [ "set_channel_mute_status", "classopenmpt_1_1ext_1_1interactive.html#a4aca685550ce5adb7a525d45f4872861", null ],
      [ "set_channel_volume", "classopenmpt_1_1ext_1_1interactive.html#a62f10ec3f8535971820e248fd39db75c", null ],
      [ "set_current_speed", "classopenmpt_1_1ext_1_1interactive.html#a7364c32129d1f1c19e878d3470c85b4e", null ],
      [ "set_current_tempo", "classopenmpt_1_1ext_1_1interactive.html#acda3b7ce32d69998b047dddca7217589", null ],
      [ "set_global_volume", "classopenmpt_1_1ext_1_1interactive.html#a21b996a4cd1baedca4a48b28319b611c", null ],
      [ "set_instrument_mute_status", "classopenmpt_1_1ext_1_1interactive.html#a902afe9f902bc0c6cd018a83e83d8446", null ],
      [ "set_pitch_factor", "classopenmpt_1_1ext_1_1interactive.html#a5c1edcf89b889efe65b1531e5c2df29c", null ],
      [ "set_tempo_factor", "classopenmpt_1_1ext_1_1interactive.html#a90ed28d6196524620a7dc8f7902fb40d", null ],
      [ "stop_note", "classopenmpt_1_1ext_1_1interactive.html#a49312b686b28617c07d414de015fb4e9", null ]
    ] ],
    [ "effect_type", "group__libopenmpt__ext__cpp.html#ga42fdf7dfd8919fa42a8bbb7754cccde3", [
      [ "effect_unknown", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3af10aa914735334b1de44aeec4870345a", null ],
      [ "effect_general", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3a2723a45bc3a57aefe507bcc7e8729ede", null ],
      [ "effect_global", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3a4431ac360b49a3381f32e3c50c8350e9", null ],
      [ "effect_volume", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3a795774dd8f93ab5714e7961449be5f8c", null ],
      [ "effect_panning", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3a7cb096c0556b747289cc9f0136f09be0", null ],
      [ "effect_pitch", "group__libopenmpt__ext__cpp.html#gga42fdf7dfd8919fa42a8bbb7754cccde3a1c789ea5244b97959b9b960094e8614e", null ]
    ] ]
];