var hierarchy =
[
    [ "std::exception", null, [
      [ "openmpt::exception", "classopenmpt_1_1exception.html", null ]
    ] ],
    [ "openmpt::ext::interactive", "classopenmpt_1_1ext_1_1interactive.html", null ],
    [ "openmpt::module", "classopenmpt_1_1module.html", [
      [ "openmpt::module_ext", "classopenmpt_1_1module__ext.html", null ]
    ] ],
    [ "openmpt_module_initial_ctl", "structopenmpt__module__initial__ctl.html", null ],
    [ "openmpt_stream_callbacks", "structopenmpt__stream__callbacks.html", null ],
    [ "openmpt::ext::pattern_vis", "classopenmpt_1_1ext_1_1pattern__vis.html", null ]
];