var libopenmpt_8hpp =
[
    [ "could_open_propability", "libopenmpt_8hpp.html#af0214e5adadae82b2ba1625198a9b515", null ],
    [ "get", "libopenmpt_8hpp.html#a5c14a09cfc6d93e26bd717c4b2cfd716", null ],
    [ "get_core_version", "libopenmpt_8hpp.html#ac37146367d4849a17a297d388cfb4811", null ],
    [ "get_library_version", "libopenmpt_8hpp.html#aeece2f6ce1045a5f519c93ce19e6eef3", null ],
    [ "get_supported_extensions", "libopenmpt_8hpp.html#aaa2081245974442462d76e8b9bc9380a", null ],
    [ "is_extension_supported", "libopenmpt_8hpp.html#aafc5dab5b9c0b8324bbedcc01b59a3c0", null ],
    [ "LIBOPENMPT_ATTR_DEPRECATED", "libopenmpt_8hpp.html#ab357d2a4b0fcc92eb1a45bb34ee214f5", null ]
];