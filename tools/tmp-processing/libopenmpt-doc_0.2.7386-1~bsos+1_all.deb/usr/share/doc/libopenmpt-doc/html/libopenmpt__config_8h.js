var libopenmpt__config_8h =
[
    [ "LIBOPENMPT_DEPRECATED", "libopenmpt__config_8h.html#a5c103073ee00995ffb7e1316c90d9f1c", null ],
    [ "LIBOPENMPT_DEPRECATED_STRING", "libopenmpt__config_8h.html#ac5bc96313b3c556c123c9fec7ee95f22", null ],
    [ "LIBOPENMPT_DEPRECATED_STRING_CONSTANT", "libopenmpt__config_8h.html#aa3c5870a3f551fc8e6d02a61bb735661", null ]
];