var libopenmpt__stream__callbacks__fd_8h =
[
    [ "openmpt_stream_fd_read_func", "libopenmpt__stream__callbacks__fd_8h.html#a534305a50c22c68f4eb4735ac6e271db", null ],
    [ "openmpt_stream_get_fd_callbacks", "libopenmpt__stream__callbacks__fd_8h.html#a9b222cad5195de39b84503c089eca611", null ]
];