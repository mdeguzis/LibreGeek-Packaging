var libopenmpt__stream__callbacks__file_8h =
[
    [ "openmpt_stream_file_read_func", "libopenmpt__stream__callbacks__file_8h.html#ab35f4ca3b71e20cabdc2febb5d48db87", null ],
    [ "openmpt_stream_file_seek_func", "libopenmpt__stream__callbacks__file_8h.html#a53dd106d28a4b68eea86fba6bfdd1b9a", null ],
    [ "openmpt_stream_file_tell_func", "libopenmpt__stream__callbacks__file_8h.html#aecc775ac3096e1a1060941e0ef8ee0ec", null ],
    [ "openmpt_stream_get_file_callbacks", "libopenmpt__stream__callbacks__file_8h.html#ac89b0366fe1f3686bcff1be86b69c79a", null ]
];