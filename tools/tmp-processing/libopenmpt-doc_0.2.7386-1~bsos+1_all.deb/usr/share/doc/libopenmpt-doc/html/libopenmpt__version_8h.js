var libopenmpt__version_8h =
[
    [ "OPENMPT_API_VERSION", "group__libopenmpt.html#gaf1d146e1fe0a48865ddd61b911d81804", null ],
    [ "OPENMPT_API_VERSION_MAJOR", "group__libopenmpt.html#ga606ec2ed5b519cd7d2a9d1a035975995", null ],
    [ "OPENMPT_API_VERSION_MINOR", "group__libopenmpt.html#ga64df542ebca546797047106263a40d1d", null ],
    [ "OPENMPT_API_VERSION_STRING", "group__libopenmpt.html#gad5b5529fa0ae48c75bb735d5e5e19243", null ]
];