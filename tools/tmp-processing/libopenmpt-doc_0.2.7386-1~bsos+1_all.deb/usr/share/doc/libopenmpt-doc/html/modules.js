var modules =
[
    [ "libopenmpt C++", "group__libopenmpt__cpp.html", "group__libopenmpt__cpp" ],
    [ "libopenmpt C", "group__libopenmpt__c.html", "group__libopenmpt__c" ],
    [ "libopenmpt", "group__libopenmpt.html", "group__libopenmpt" ],
    [ "libopenmpt_ext C++", "group__libopenmpt__ext__cpp.html", "group__libopenmpt__ext__cpp" ]
];