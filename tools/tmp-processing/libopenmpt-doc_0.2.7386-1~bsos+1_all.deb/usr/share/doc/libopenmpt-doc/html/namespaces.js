var namespaces =
[
    [ "openmpt", "namespaceopenmpt.html", "namespaceopenmpt" ]
];