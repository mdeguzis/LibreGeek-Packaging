var searchData=
[
  ['dependencies',['Dependencies',['../dependencies.html',1,'']]],
  ['dependencies_2emd',['dependencies.md',['../dependencies_8md.html',1,'']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]]
];
