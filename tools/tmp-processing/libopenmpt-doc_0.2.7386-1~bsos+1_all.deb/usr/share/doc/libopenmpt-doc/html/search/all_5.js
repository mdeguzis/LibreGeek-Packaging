var searchData=
[
  ['highlight_5fpattern_5frow_5fchannel',['highlight_pattern_row_channel',['../classopenmpt_1_1module.html#a6b871ce76342f54427a75a3ede811fef',1,'openmpt::module']]],
  ['highlight_5fpattern_5frow_5fchannel_5fcommand',['highlight_pattern_row_channel_command',['../classopenmpt_1_1module.html#a642700c4f49b36379b077f99b856bdbe',1,'openmpt::module']]]
];
