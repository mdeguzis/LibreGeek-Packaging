var searchData=
[
  ['quick_20start',['Quick Start',['../quickstart.html',1,'']]],
  ['quickstart_2emd',['quickstart.md',['../quickstart_8md.html',1,'']]]
];
