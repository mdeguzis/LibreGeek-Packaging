var searchData=
[
  ['openmpt_5fmodule_5finitial_5fctl',['openmpt_module_initial_ctl',['../structopenmpt__module__initial__ctl.html',1,'']]],
  ['openmpt_5fstream_5fcallbacks',['openmpt_stream_callbacks',['../structopenmpt__stream__callbacks.html',1,'']]]
];
