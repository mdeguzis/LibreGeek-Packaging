var searchData=
[
  ['pattern_5fvis',['pattern_vis',['../classopenmpt_1_1ext_1_1pattern__vis.html',1,'openmpt::ext']]]
];
