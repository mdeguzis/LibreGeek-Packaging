var searchData=
[
  ['dependencies_2emd',['dependencies.md',['../dependencies_8md.html',1,'']]]
];
