var searchData=
[
  ['changelog',['Changelog',['../changelog.html',1,'']]],
  ['contents',['Contents',['../index.html',1,'']]],
  ['c_20api',['C API',['../libopenmpt_c_overview.html',1,'']]],
  ['c_2b_2b_20api',['C++ API',['../libopenmpt_cpp_overview.html',1,'']]]
];
