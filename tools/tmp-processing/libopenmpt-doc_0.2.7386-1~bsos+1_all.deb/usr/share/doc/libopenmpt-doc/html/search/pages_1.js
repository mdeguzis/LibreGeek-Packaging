var searchData=
[
  ['dependencies',['Dependencies',['../dependencies.html',1,'']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]]
];
