var searchData=
[
  ['openmpt_5flog_5ffunc',['openmpt_log_func',['../group__libopenmpt__c.html#ga5c22e7546d42f3cb4a6fb65bd4962855',1,'libopenmpt.h']]],
  ['openmpt_5fmodule',['openmpt_module',['../group__libopenmpt__c.html#gadb90c01fba5864c0359a28c2d4151dd7',1,'libopenmpt.h']]],
  ['openmpt_5fmodule_5finitial_5fctl',['openmpt_module_initial_ctl',['../group__libopenmpt__c.html#gab80d8d1ce0d36ff2d7e7fca314dc9af8',1,'libopenmpt.h']]],
  ['openmpt_5fstream_5fcallbacks',['openmpt_stream_callbacks',['../group__libopenmpt__c.html#ga0d95b2f481612b600a09ee2ebee4d522',1,'libopenmpt.h']]],
  ['openmpt_5fstream_5fread_5ffunc',['openmpt_stream_read_func',['../group__libopenmpt__c.html#gaa5decf2dc2629aa6d0ad356c238eda33',1,'libopenmpt.h']]],
  ['openmpt_5fstream_5fseek_5ffunc',['openmpt_stream_seek_func',['../group__libopenmpt__c.html#ga7379cc5abec36255ee321becbb7f5d5b',1,'libopenmpt.h']]],
  ['openmpt_5fstream_5ftell_5ffunc',['openmpt_stream_tell_func',['../group__libopenmpt__c.html#ga42f837163e1fba9f3063ffd49994e614',1,'libopenmpt.h']]]
];
