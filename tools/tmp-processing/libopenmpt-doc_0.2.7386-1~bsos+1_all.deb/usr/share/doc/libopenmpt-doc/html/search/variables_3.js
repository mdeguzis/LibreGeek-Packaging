var searchData=
[
  ['pattern_5fvis_5fid',['pattern_vis_id',['../namespaceopenmpt_1_1ext.html#ac9a8f10e0115843aa2b8668247446a2b',1,'openmpt::ext']]]
];
