var searchData=
[
  ['read',['read',['../structopenmpt__stream__callbacks.html#a1ebf210f90c37ea1bb3ff0342039d8ae',1,'openmpt_stream_callbacks']]]
];
