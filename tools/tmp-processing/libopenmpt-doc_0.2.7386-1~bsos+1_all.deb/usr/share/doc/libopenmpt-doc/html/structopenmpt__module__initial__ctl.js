var structopenmpt__module__initial__ctl =
[
    [ "ctl", "structopenmpt__module__initial__ctl.html#a085cbbbe2b15ab763fcb20f0bdcfe5e8", null ],
    [ "value", "structopenmpt__module__initial__ctl.html#a11fbe4f662ac10d8deaad8891a88ddbb", null ]
];